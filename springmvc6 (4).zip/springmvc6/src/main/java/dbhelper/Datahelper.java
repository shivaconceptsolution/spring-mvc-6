package dbhelper;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import models.Emp;

public class Datahelper {
	static Configuration cfg;
	static SessionFactory sf;
	static Session sess;
	static Transaction tx;
    public static void connect()
    {
	    cfg= new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    sf = cfg.buildSessionFactory();
	    sess = sf.openSession();
    }
   
    public static void insertOperation(Object obj)
   {
	   tx= sess.beginTransaction();
	   sess.save(obj);
	   tx.commit();
   }
    public  static void updateOperation(Object obj)
   {
	   tx= sess.beginTransaction();
	   sess.update(obj);
	   tx.commit();
   }
    public  static void deleteOperation(Object obj)
   {
	   tx= sess.beginTransaction();
	   sess.delete(obj);
	   tx.commit();
   }
   
    public static Query selectOperation(String query)
   {
	    Query q = sess.createQuery(query);
	    return q;
   }
   
    public static Object findOperation(Class c,Integer id)
   {
	   Object o = sess.get(c,id);
	   return o;
   }
   public  static void closeConn()
   {
	   sess.close();
   }
   
}
