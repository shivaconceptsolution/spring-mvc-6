package models;

import javax.persistence.*;

@Entity
@Table(name="emp")
public class Emp {
@Id	
private int empid;
@Column
private String empname;
@Column
private String username;
@Column
private String password;
@Column
private String job;

public int getEmpid() {

	return empid;

}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public void setEmpid(int empid) {

	this.empid = empid;

}

public String getEmpname() {

	return empname;

}

public void setEmpname(String empname) {

	this.empname = empname;

}

public String getJob() {

	return job;

}

public void setJob(String job) {

	this.job = job;

}

}