package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dbhelper.Datahelper;
import models.Emp;
import services.Empbean;

@Controller
public class EmployeeController {
	@RequestMapping("emp")
     public ModelAndView empInfo(HttpSession session){
		if(session.getAttribute("sessuid")==null)
		{
			return new ModelAndView("redirect:admin.do");
		}
    	ModelAndView obj= new ModelAndView("empview","command",new Empbean());
        obj.addObject("res1",getEmpData());
        obj.addObject("btntitle","Insert");
    	return obj;
    }	
	@RequestMapping("empfind")
    public ModelAndView empfindInfo(HttpServletRequest request){
	   Emp emp = findEmpData(Integer.parseInt(request.getParameter("q").toString()));	
   	   ModelAndView obj= new ModelAndView("empview","command",emp);
       obj.addObject("res1",getEmpData());
       obj.addObject("btntitle","Update");
   	   return obj;
   }	
	@RequestMapping("empinsert")
    public ModelAndView empInsert(@ModelAttribute("springmvc6")Empbean s,HttpServletRequest request){
		String msg="";
		if(request.getParameter("btnsubmit").equals("Insert"))
		{
		insertEmpData(s);
		msg="data inserted successfully";
		}
		else
		{
		updateEmpData(s);
		msg="data updated successfully";
		}
		ModelAndView obj1= new ModelAndView("empview","command",new Empbean());
		obj1.addObject("res",msg);
		obj1.addObject("res1",getEmpData());
		obj1.addObject("btntitle","Insert");
		return obj1;

   }
	@RequestMapping("empupdate")
    public ModelAndView empUpdate(@ModelAttribute("springmvc6")Empbean s){
		updateEmpData(s);
		ModelAndView obj1= new ModelAndView("empview","command",new Empbean());
		obj1.addObject("res","data inserted successfully");
		obj1.addObject("res1",getEmpData());
		obj1.addObject("btntitle","Insert");
		return obj1;

   }
public void insertEmpData(Empbean s)
{
	Datahelper.connect();
    Emp obj = new Emp();
    obj.setEmpid(s.getEmpid());
    obj.setEmpname(s.getEmpname());
    obj.setUsername(s.getUsername());
    obj.setPassword(s.getPassword());
    obj.setJob(s.getJob());
    Datahelper.insertOperation(obj);
    Datahelper.closeConn();
}
public void updateEmpData(Empbean s)
{
	Datahelper.connect();
    Emp obj = new Emp();
    obj.setEmpid(s.getEmpid());
    obj.setEmpname(s.getEmpname());
    obj.setJob(s.getJob());
    Datahelper.updateOperation(obj);
    Datahelper.closeConn();
}
public List getEmpData()
{
	Datahelper.connect();
    Query q = Datahelper.selectOperation("from Emp s");
    List lst = q.list();
    return lst;
}
public Emp findEmpData(int id)
{
	Datahelper.connect();
    Object o = Datahelper.findOperation(Emp.class,id);
    Emp e = (Emp)o;
    return e;
   
}
}
