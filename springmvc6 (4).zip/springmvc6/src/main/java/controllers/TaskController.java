package controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import models.Emp;
import models.Task;
import services.Empbean;

@Controller
public class TaskController {
	@RequestMapping("addtask")
	  public ModelAndView addTask(HttpSession session){
			if(session.getAttribute("sessuid")==null)
			{
				return new ModelAndView("redirect:admin.do");
			}
	    	ModelAndView obj= new ModelAndView("taskadd","command",new Task());
	        obj.addObject("empdata",new EmployeeController().getEmpData());
	        obj.addObject("taskdata",viewTaskData());
	    	return obj;
	    }	
	@RequestMapping("taskinsert")
	  public ModelAndView insertTask(@ModelAttribute("springmvc6")Task s){
			
	    	ModelAndView obj= new ModelAndView("taskadd","command",new Task());
	        insertTaskData(s);
	        obj.addObject("empdata",new EmployeeController().getEmpData());
	        obj.addObject("key","Insert Successfully");
	        obj.addObject("taskdata",viewTaskData());
	    	return obj;
	    }	
	@RequestMapping("taskview")
	  public ModelAndView viewTask(@ModelAttribute("springmvc6")Task s){
			
	    	ModelAndView obj= new ModelAndView("taskadd","command",new Task());
	        insertTaskData(s);
	        obj.addObject("empdata",new EmployeeController().getEmpData());
	       
	    	return obj;
	    }	
	
	public void insertTaskData(Task s)
	{
		Configuration cfg = new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session sess = sf.openSession();
	    Transaction tx= sess.beginTransaction();
	    sess.save(s);
	    tx.commit();
	    sess.close();
	}
	public List viewTaskData()
	{
		Configuration cfg = new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session sess = sf.openSession();
	    return sess.createQuery("from Task c").list();
	    
	}
}
