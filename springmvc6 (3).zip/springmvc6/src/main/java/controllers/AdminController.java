package controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import models.Admin;
import services.Adminbean;
import services.Empbean;

@Controller
public class AdminController {
    @RequestMapping("admin")
	public ModelAndView login()
	{
		return new ModelAndView("login","command",new Adminbean());
	}
    @RequestMapping("logincode")
	public ModelAndView logincode(@ModelAttribute("springmvc6")Adminbean obj,HttpSession session)
	{
		if(loginData(obj.getUname(),obj.getUpass()))
		{
			session.setAttribute("sessuid",obj.getUname());
			return new ModelAndView("redirect:emp.do");
		}
		else
		{
		return new ModelAndView("login","command",new Adminbean()).addObject("key","Invalid userid and password");
		}
	}
    @RequestMapping("logout")
	public ModelAndView logout(HttpSession session)
	{
    	session.removeAttribute("sessuid");
		return new ModelAndView("redirect:admin.do");
	}
	public boolean loginData(String username,String password)
	{
		Configuration cfg = new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session sess = sf.openSession();
	    Admin admin = new Admin();
	    admin.setUsername(username);
	    admin.setPassword(password);
	    Query q = sess.createQuery("from Admin a where a.username=:u and a.password=:b");
	    q.setString("u",admin.getUsername());
	    q.setString("b",admin.getPassword());
	    List lst = q.list();
	    if(lst.size()>0)
	    {
	    	return true;
	    }
	    else
	    {
	    	return false;
	    }
	   
	}
}
