package controllers;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import models.Admin;
import models.Emp;
import services.Adminbean;
import services.Empbean;
@Controller
public class EmployeeDashboardController {
	@RequestMapping("login")
	public ModelAndView login()
	{
		return new ModelAndView("emplogin","command",new Empbean());
	}
    @RequestMapping("emplogincode")
	public ModelAndView logincode(@ModelAttribute("springmvc6")Empbean obj,HttpSession session)
	{
		if(loginData(obj.getUsername(),obj.getPassword()))
		{
			session.setAttribute("sesseid",findEmpid(obj.getUsername()));
			return new ModelAndView("empdash","assigndata",findTaskData(findEmpid(obj.getUsername())));
		}
		else
		{
		return new ModelAndView("emplogin","command",new Empbean()).addObject("key","Invalid userid and password");
		}
	}
    @RequestMapping("emplogout")
  	public ModelAndView logout(HttpSession session)
  	{
      	session.removeAttribute("sessuid");
  		return new ModelAndView("redirect:login.do");
  	}
    @RequestMapping("empdash")
	public ModelAndView empdash()
	{
		return new ModelAndView("empdash");
	}
  	public boolean loginData(String username,String password)
  	{
  		Configuration cfg = new Configuration();
  	    cfg.configure("hibernate.cfg.xml");
  	    SessionFactory sf = cfg.buildSessionFactory();
  	    Session sess = sf.openSession();
  	     Emp e = new Emp();
  	     e.setUsername(username);
  	     e.setPassword(password);
  	    Query q = sess.createQuery("from Emp a where a.username=:u and a.password=:b");
  	    q.setString("u",e.getUsername());
  	    q.setString("b",e.getPassword());
  	    List lst = q.list();
  	    if(lst.size()>0)
  	    {
  	    	return true;
  	    }
  	    else
  	    {
  	    	return false;
  	    }
  	   
  	}
  	public List findTaskData(int id)
  	{
  		Configuration cfg = new Configuration();
  	    cfg.configure("hibernate.cfg.xml");
  	    SessionFactory sf = cfg.buildSessionFactory();
  	    Session sess = sf.openSession();
  	    Query o = sess.createQuery("from Task t where t.empid=:a");
  	    o.setInteger("a",id);
  	    return o.list();
  	   
  	}
  	public int findEmpid(String username)
  	{
  		Configuration cfg = new Configuration();
  	    cfg.configure("hibernate.cfg.xml");
  	    SessionFactory sf = cfg.buildSessionFactory();
  	    Session sess = sf.openSession();
  	    Query o = sess.createQuery("from Emp t where t.username=:a");
  	    o.setString("a",username);
  	    List lt = o.list();
  	    Iterator it = lt.iterator();
  	    int empid=0;
  	    while(it.hasNext())
  	    {
  	    	Emp e=(Emp)it.next();
  	    	empid=e.getEmpid();
  	    }
  	    return empid;
  	   
  	}
}
