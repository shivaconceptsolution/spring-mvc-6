package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Addition {
	@RequestMapping("add")
	public ModelAndView addition()
	{
		int a=100;
		int b=200;
		int c=a+b;
		return new ModelAndView("add","key","result is "+c);
	}

}
