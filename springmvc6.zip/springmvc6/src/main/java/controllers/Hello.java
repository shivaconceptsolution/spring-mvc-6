package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Hello {
	  @RequestMapping("/ram")
	 public String test()
	    {
	        return "ramview";
	    }
	  @RequestMapping("/welcome")
		 public String test1()
		    {
		        return "welcome";
		    }
}
